package com.personal.watchtranslate.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.watchtranslate.data.model.SubtitleCue
import com.personal.watchtranslate.data.model.SubtitleExplanation
import com.personal.watchtranslate.data.model.SubtitleStyleConfig
import com.personal.watchtranslate.ui.theme.*

@Composable
fun SubtitleOverlay(
    activeCue: SubtitleCue?,
    style: SubtitleStyleConfig,
    onTapCue: (SubtitleCue) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val topPadding = (maxHeight * style.verticalPositionBias.coerceIn(0.12f, 0.88f)) - 56.dp

        AnimatedVisibility(
            visible = activeCue != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = topPadding.coerceAtLeast(16.dp), start = 20.dp, end = 20.dp)
        ) {
            activeCue?.let { cue ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = style.bgOpacity))
                        .clickable { onTapCue(cue) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(
                            text = cue.translatedText,
                            color = Color(style.textColorHex),
                            fontSize = style.fontSizeSp.sp,
                            lineHeight = (style.fontSizeSp * 1.35f).sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center
                        )
                    }
                    if (style.showOriginalText && cue.sourceText.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = cue.sourceText,
                            color = MutedSlate,
                            fontSize = (style.fontSizeSp * 0.68f).sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiExplanationBottomSheet(
    isLoading: Boolean,
    explanation: SubtitleExplanation?,
    onDismiss: () -> Unit
) {
    if (!isLoading && explanation == null) return

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = CharcoalSurface,
        contentColor = SoftWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "AI Context Breakdown",
                style = MaterialTheme.typography.titleMedium,
                color = ElectricPurple,
                fontWeight = FontWeight.Bold
            )

            if (isLoading) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(vertical = 24.dp)
                ) {
                    CircularProgressIndicator(color = ElectricPurple, modifier = Modifier.size(22.dp))
                    Text("Analyzing idioms, tone, and context...", color = MutedSlate)
                }
            } else if (explanation != null) {
                Surface(color = ElevatedCharcoal, shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(explanation.original, color = SoftWhite, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(6.dp))
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(
                                explanation.translation,
                                color = VividBlue,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    ExplanationBlock("المعنى في السياق", explanation.meaningInContext)
                    ExplanationBlock("العامية والتعبيرات", explanation.slangOrIdiomNotes)
                    ExplanationBlock("بالمصري الطبيعي", explanation.egyptianVersion)
                    if (explanation.alternatives.isNotEmpty()) {
                        ExplanationBlock("ترجمات بديلة", explanation.alternatives.joinToString("\n• ", prefix = "• "))
                    }
                }
                ExplanationBlock("Pronunciation", explanation.pronunciationGuide)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun ExplanationBlock(label: String, content: String) {
    if (content.isBlank()) return
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = MutedSlate, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(2.dp))
        Text(content, color = SoftWhite, style = MaterialTheme.typography.bodyMedium)
    }
}
