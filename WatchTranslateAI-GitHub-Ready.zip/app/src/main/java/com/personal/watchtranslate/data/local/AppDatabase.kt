package com.personal.watchtranslate.data.local

import android.content.Context
import androidx.room.*
import com.personal.watchtranslate.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BrowserDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun observeBookmarks(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBookmark(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun deleteBookmark(url: String)

    @Query("SELECT * FROM history ORDER BY visitedAt DESC LIMIT 100")
    fun observeHistory(): Flow<List<HistoryEntity>>

    @Insert
    suspend fun insertHistory(entry: HistoryEntity)

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    @Query("SELECT * FROM translation_cache WHERE cacheKey = :key LIMIT 1")
    suspend fun getCachedTranslation(key: String): TranslationCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCachedTranslation(entity: TranslationCacheEntity)

    @Query("DELETE FROM translation_cache")
    suspend fun clearTranslationCache()

    @Query("SELECT * FROM translation_history ORDER BY timestamp DESC LIMIT 150")
    fun observeTranslationHistory(): Flow<List<TranslationHistoryEntity>>

    @Insert
    suspend fun insertTranslationHistory(entry: TranslationHistoryEntity)

    @Query("DELETE FROM translation_history")
    suspend fun clearTranslationHistory()

    @Query("SELECT * FROM adblock_rules")
    fun observeAdBlockRules(): Flow<List<AdBlockRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAdBlockRule(rule: AdBlockRuleEntity)

    @Query("DELETE FROM adblock_rules WHERE domain = :domain")
    suspend fun deleteAdBlockRule(domain: String)
}

@Database(
    entities = [
        BookmarkEntity::class,
        HistoryEntity::class,
        TranslationCacheEntity::class,
        TranslationHistoryEntity::class,
        AdBlockRuleEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun browserDao(): BrowserDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "watchtranslate_local.db"
            ).build().also { INSTANCE = it }
        }
    }
}
