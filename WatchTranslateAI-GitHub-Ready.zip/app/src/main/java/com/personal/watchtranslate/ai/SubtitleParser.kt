package com.personal.watchtranslate.ai

data class RawCaptionCue(val startMs: Long, val endMs: Long, val text: String)

object SubtitleParser {
    private val timeRegex = Regex("""(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})""")

    fun parseVttOrSrt(content: String): List<RawCaptionCue> {
        val result = mutableListOf<RawCaptionCue>()
        val blocks = content.replace("\r\n", "\n").split("\n\n")
        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val timingIdx = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
            if (timingIdx == -1) continue
            val match = timeRegex.find(lines[timingIdx]) ?: continue

            val startMs = toMs(match.groupValues[1], match.groupValues[2], match.groupValues[3], match.groupValues[4])
            val endMs = toMs(match.groupValues[5], match.groupValues[6], match.groupValues[7], match.groupValues[8])
            val text = lines.drop(timingIdx + 1)
                .joinToString("\n")
                .replace(Regex("<[^>]*>"), "")
                .trim()
            if (text.isNotEmpty() && endMs > startMs) {
                result.add(RawCaptionCue(startMs, endMs, text))
            }
        }
        return result
    }

    private fun toMs(h: String, m: String, s: String, ms: String): Long {
        val hours = h.removeSuffix(":").toLongOrNull() ?: 0L
        return hours * 3_600_000L + m.toLong() * 60_000L + s.toLong() * 1000L + ms.toLong()
    }
}
