package com.personal.watchtranslate.browser

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import com.personal.watchtranslate.data.local.BrowserDao
import com.personal.watchtranslate.data.model.AdBlockRuleEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

class AdBlockerEngine(
    private val context: Context,
    private val dao: BrowserDao,
    private val scope: CoroutineScope
) {
    private val blockedDomains = ConcurrentHashMap.newKeySet<String>()
    private val customBlockedDomains = ConcurrentHashMap.newKeySet<String>()
    private val whitelistedSites = ConcurrentHashMap.newKeySet<String>()
    private val httpClient = OkHttpClient()

    private val _isEnabled = MutableStateFlow(true)
    val isEnabled = _isEnabled.asStateFlow()

    private val _totalBlocked = MutableStateFlow(0)
    val totalBlocked = _totalBlocked.asStateFlow()

    private val counter = AtomicInteger(0)

    init {
        loadBundledBlocklist()
        scope.launch(Dispatchers.IO) {
            dao.observeAdBlockRules().collect { rules ->
                whitelistedSites.clear()
                customBlockedDomains.clear()
                rules.forEach { rule ->
                    if (rule.isWhitelist) whitelistedSites.add(rule.domain.lowercase())
                    else customBlockedDomains.add(rule.domain.lowercase())
                }
            }
        }
    }

    private fun loadBundledBlocklist() {
        runCatching {
            context.assets.open("default_adblock_domains.txt").bufferedReader().useLines { lines ->
                lines.map { it.trim().lowercase() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                    .forEach { blockedDomains.add(it) }
            }
        }
    }

    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
    }

    fun isSiteWhitelisted(pageUrl: String?): Boolean {
        val host = extractHost(pageUrl) ?: return false
        return matchesDomainSet(host, whitelistedSites)
    }

    fun toggleSiteWhitelist(pageUrl: String) {
        val host = extractHost(pageUrl) ?: return
        scope.launch(Dispatchers.IO) {
            if (whitelistedSites.contains(host)) {
                dao.deleteAdBlockRule(host)
            } else {
                dao.upsertAdBlockRule(AdBlockRuleEntity(domain = host, isWhitelist = true))
            }
        }
    }

    fun addCustomBlockedDomain(domain: String) {
        val clean = domain.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
        if (clean.contains(".")) {
            scope.launch(Dispatchers.IO) {
                dao.upsertAdBlockRule(AdBlockRuleEntity(domain = clean, isWhitelist = false))
            }
        }
    }

    suspend fun updateBlocklistFromUrl(
        listUrl: String = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0"
    ): Result<Int> {
        return runCatching {
            val req = Request.Builder().url(listUrl).build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("HTTP ${resp.code}")
                val body = resp.body?.string().orEmpty()
                var added = 0
                body.lineSequence().forEach { raw ->
                    val line = raw.trim().lowercase()
                    if (line.isNotEmpty() && !line.startsWith("#") && !line.startsWith("!")) {
                        val domain = line.removePrefix("0.0.0.0 ").removePrefix("127.0.0.1 ").trim()
                        if (domain.contains(".") && blockedDomains.add(domain)) added++
                    }
                }
                added
            }
        }
    }

    fun shouldBlockRequest(requestUrl: String, currentPageUrl: String?): Boolean {
        if (!_isEnabled.value) return false
        if (isSiteWhitelisted(currentPageUrl)) return false

        val reqHost = extractHost(requestUrl) ?: return false
        val pageHost = extractHost(currentPageUrl)

        if (pageHost != null && (reqHost == pageHost || reqHost.endsWith(".$pageHost"))) {
            val lowerPath = requestUrl.lowercase()
            if (!lowerPath.contains("/pagead/") && !lowerPath.contains("/popunder")) {
                return false
            }
        }

        val blocked = matchesDomainSet(reqHost, blockedDomains) ||
            matchesDomainSet(reqHost, customBlockedDomains)

        if (blocked) {
            _totalBlocked.value = counter.incrementAndGet()
        }
        return blocked
    }

    fun shouldBlockPopupOrRedirect(targetUrl: String, currentPageUrl: String?, hasUserGesture: Boolean): Boolean {
        if (!_isEnabled.value || isSiteWhitelisted(currentPageUrl)) return false
        val targetHost = extractHost(targetUrl) ?: return true
        if (matchesDomainSet(targetHost, blockedDomains) || matchesDomainSet(targetHost, customBlockedDomains)) {
            _totalBlocked.value = counter.incrementAndGet()
            return true
        }
        val currentHost = extractHost(currentPageUrl)
        if (!hasUserGesture && currentHost != null && !targetHost.endsWith(currentHost)) {
            val lower = targetUrl.lowercase()
            if (lower.contains("click") || lower.contains("redirect") || lower.contains("promo") || lower.contains("offer")) {
                _totalBlocked.value = counter.incrementAndGet()
                return true
            }
        }
        return false
    }

    fun emptyBlockedResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    val cosmeticHideCssJs: String = """
        (function(){
          if(document.getElementById('wt-cosmetic-css')) return;
          const style = document.createElement('style');
          style.id = 'wt-cosmetic-css';
          style.textContent = `
            ins.adsbygoogle, [id^="google_ads_iframe"], .ad-banner, .pop-overlay,
            div[class*="ad-container"]:not(:has(video)), iframe[src*="doubleclick"] {
              display: none !important; visibility: hidden !important;
            }
          `;
          (document.head || document.documentElement).appendChild(style);
        })();
    """.trimIndent()

    private fun extractHost(url: String?): String? =
        runCatching { Uri.parse(url).host?.lowercase()?.removePrefix("www.") }.getOrNull()

    private fun matchesDomainSet(host: String, set: Set<String>): Boolean {
        var current = host
        while (current.contains(".")) {
            if (set.contains(current)) return true
            current = current.substringAfter(".")
        }
        return false
    }
}
