# WatchTranslate AI

Personal-use Android translating browser built with Kotlin, Jetpack Compose, WebView, Room, MediaProjection Audio Capture, Deepgram Streaming STT, and Gemini / OpenAI context-aware Arabic subtitle translation.

## Build via GitHub Actions
1. Push all files to a private GitHub repository.
2. Open the **Actions** tab → **Build WatchTranslate AI APK** → **Run workflow**.
3. Download the `WatchTranslate-AI-APK` artifact and install `app-debug.apk`.
